<?php 
require_once "conexion.php";
class ModeloFormularios{

	#selecciono registros
	static public function mdlSeleccionarRegistros($tabla, $item, $valor){
		if($item==null && $valor==null){
			$stmt=Conexion::conectar()->prepare("SELECT * FROM $tabla");
			$stmt->execute();
			return $stmt->fetchAll();
		}else{
			$stmt=Conexion::conectar()->prepare("SELECT * FROM $tabla WHERE $item = :$item");
			$stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
			$stmt->execute();
			return $stmt->fetch();
		}

		$stmt->close();
		$stmt=null;
	}
	#selecciono registros principal filtro activo
	static public function mdlSeleccionarRegistrosActivo($tabla, $item, $valor){
		if($item==null && $valor==null){
			$stmt=Conexion::conectar()->prepare("SELECT * FROM $tabla WHERE activo =1");
			$stmt->execute();
			return $stmt->fetchAll();
		}else{
			$stmt=Conexion::conectar()->prepare("SELECT * FROM $tabla WHERE $item = :$item");
			$stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
			$stmt->execute();
			return $stmt->fetch();
		}

		$stmt->close();
		$stmt=null;
	}
	#selecciono registros planilla varios SEGUN DIA
	static public function mdlSeleccionarRegistrosplanilla($tabla, $item, $valor, $item2, $valor2){
		$stmt=Conexion::conectar()->prepare("SELECT * FROM $tabla WHERE ($item = :$item) AND ($item2= :$item2)");
		$stmt->bindParam(":".$item, $valor, PDO::PARAM_INT);
		$stmt->bindParam(":".$item2, $valor2, PDO::PARAM_STR);
		$stmt->execute();
		return $stmt->fetchAll();

		$stmt->close();
		$stmt=null;
	}


		#registro planilla viaje
	static public function mdlRegistro($tabla, $datos){
		$stmt=Conexion::conectar()->prepare("INSERT INTO $tabla(id_chofer, hora_salida, salida, destino, hora_llegada, importe) VALUES (:id_chofer, :hora_salida, :salida, :destino, :hora_llegada, :importe)");
		$stmt->bindParam(":id_chofer",$datos["id_chofer"], PDO::PARAM_INT);
		$stmt->bindParam(":hora_salida",$datos["hora_salida"], PDO::PARAM_STR);
		$stmt->bindParam(":salida",$datos["salida"], PDO::PARAM_STR);
		$stmt->bindParam(":destino",$datos["destino"], PDO::PARAM_STR);
		$stmt->bindParam(":hora_llegada",$datos["hora_llegada"], PDO::PARAM_STR);
		$stmt->bindParam(":importe",$datos["importe"], PDO::PARAM_INT);
		if($stmt->execute()){
			return "ok";
		}else{
			print_r(Conexion::conectar()->errorInfo());
		}
		$stmt->close();
		$stmt=null;
	}

		#registro chofer
	static public function mdlRegistroChofer($tabla, $datos){
		$stmt=Conexion::conectar()->prepare("INSERT INTO $tabla(nombre, auto, porcentaje, activo, dinero) VALUES (:nombre, :auto, :porcentaje, 0, 0)");
		$stmt->bindParam(":nombre",$datos["nombre"], PDO::PARAM_STR);
		$stmt->bindParam(":auto",$datos["auto"], PDO::PARAM_STR);
		$stmt->bindParam(":porcentaje",$datos["porcentaje"], PDO::PARAM_INT);
		if($stmt->execute()){
			return "ok";
		}else{
			print_r(Conexion::conectar()->errorInfo());
		}
		$stmt->close();
		$stmt=null;
	}
	#eliminar registro chofer
	static public function mdlEliminarRegistro($tabla, $valor){
		$stmt=Conexion::conectar()->prepare("DELETE FROM $tabla WHERE id_chofer=:id_chofer");
		$stmt->bindParam(":id_chofer", $valor, PDO::PARAM_INT);
		if($stmt->execute()){
			return "ok";
		}else{
			print_r(Conexion::conectar()->errorInfo());
		}
		$stmt->close();
		$stmt=null;
	}
	#actualizar registro chofer
	static public function mdlActualizarRegistro($tabla, $datos){
		$stmt=Conexion::conectar()->prepare("UPDATE $tabla SET nombre=:nombre, auto=:auto, activo=:activo, porcentaje=:porcentaje, llegada=:llegada WHERE id_chofer=:id_chofer");
		$stmt->bindParam(":id_chofer",$datos["id_chofer"], PDO::PARAM_INT);
		$stmt->bindParam(":nombre",$datos["nombre"], PDO::PARAM_STR);
		$stmt->bindParam(":auto",$datos["auto"], PDO::PARAM_STR);
		$stmt->bindParam(":activo",$datos["activo"], PDO::PARAM_INT);
		$stmt->bindParam(":porcentaje",$datos["porcentaje"], PDO::PARAM_INT);
		$stmt->bindParam(":llegada",$datos["llegada"], PDO::PARAM_INT);
		if($stmt->execute()){
			return "ok";
		}else{
			print_r(Conexion::conectar()->errorInfo());
		}
		$stmt->close();
		$stmt=null;
	}


		#registro cuenta
	static public function mdlRegistroCuenta($tabla, $datos){
		$stmt=Conexion::conectar()->prepare("INSERT INTO $tabla(user, password, puesto, id_chofer) VALUES (:user, :password, :puesto, :id_chofer)");
		$stmt->bindParam(":user",$datos["user"], PDO::PARAM_STR);
		$stmt->bindParam(":password",$datos["password"], PDO::PARAM_STR);
		$stmt->bindParam(":puesto",$datos["puesto"], PDO::PARAM_STR);
		$stmt->bindParam(":id_chofer",$datos["id_chofer"], PDO::PARAM_INT);
		if($stmt->execute()){
			return "ok";
		}else{
			print_r(Conexion::conectar()->errorInfo());
		}
		$stmt->close();
		$stmt=null;
	}


	#eliminar sesion
	static public function mdlEliminarSesion($tabla, $valor){
		$stmt=Conexion::conectar()->prepare("DELETE FROM $tabla WHERE id=:id");
		$stmt->bindParam(":id", $valor, PDO::PARAM_INT);
		if($stmt->execute()){
			return "ok";
		}else{
			print_r(Conexion::conectar()->errorInfo());
		}
		$stmt->close();
		$stmt=null;
	}

	#actualizar sesion
	static public function mdlActualizarSesion($tabla, $datos){
		$stmt=Conexion::conectar()->prepare("UPDATE $tabla SET user=:user, password=:password, puesto=:puesto WHERE id=:id");
		$stmt->bindParam(":id",$datos["id"], PDO::PARAM_INT);
		$stmt->bindParam(":user",$datos["user"], PDO::PARAM_STR);
		$stmt->bindParam(":password",$datos["password"], PDO::PARAM_STR);
		$stmt->bindParam(":puesto",$datos["puesto"], PDO::PARAM_STR);
		if($stmt->execute()){
			return "ok";
		}else{
			print_r(Conexion::conectar()->errorInfo());
		}
		$stmt->close();
		$stmt=null;
	}

		#eliminar planilla
	static public function mdlEliminarPlanilla($tabla, $valor){
		$stmt=Conexion::conectar()->prepare("DELETE FROM $tabla WHERE id_planilla=:id_planilla");
		$stmt->bindParam(":id_planilla", $valor, PDO::PARAM_INT);
		if($stmt->execute()){
			return "ok";
		}else{
			print_r(Conexion::conectar()->errorInfo());
		}
		$stmt->close();
		$stmt=null;
	}


	#actualizar registro planilla
	static public function mdlActualizarPlanilla($tabla, $datos){
		$stmt=Conexion::conectar()->prepare("UPDATE $tabla SET hora_salida=:hora_salida, salida=:salida, destino=:destino, hora_llegada=:hora_llegada, importe=:importe WHERE id_planilla=:id_planilla");
		$stmt->bindParam(":id_planilla",$datos["id_planilla"], PDO::PARAM_INT);
		$stmt->bindParam(":hora_salida",$datos["hora_salida"], PDO::PARAM_STR);
		$stmt->bindParam(":salida",$datos["salida"], PDO::PARAM_STR);
		$stmt->bindParam(":destino",$datos["destino"], PDO::PARAM_STR);
		$stmt->bindParam(":hora_llegada",$datos["hora_llegada"], PDO::PARAM_STR);
		$stmt->bindParam(":importe",$datos["importe"], PDO::PARAM_INT);
		if($stmt->execute()){
			return "ok";
		}else{
			print_r(Conexion::conectar()->errorInfo());
		}
		$stmt->close();
		$stmt=null;
	}
	
	#actualizar registro planilla
	static public function mdlActualizarPlanillaDEVOLUCION($tabla, $datos){
		$stmt=Conexion::conectar()->prepare("UPDATE $tabla SET devolucion=:devolucion  WHERE id_planilla=:id_planilla");
		$stmt->bindParam(":id_planilla",$datos["id_planilla"], PDO::PARAM_INT);
		$stmt->bindParam(":devolucion",$datos["devolucion"], PDO::PARAM_STR);
	
		if($stmt->execute()){
			return "ok";
		}else{
			print_r(Conexion::conectar()->errorInfo());
		}
		$stmt->close();
		$stmt=null;
	}

	#actualizar dinero chofer
	static public function mdlActualizarDinero($tabla, $datos){
		$stmt=Conexion::conectar()->prepare("UPDATE $tabla SET dinero=:dinero WHERE id_chofer=:id_chofer");
		$stmt->bindParam(":id_chofer",$datos["id_chofer"], PDO::PARAM_INT);
		$stmt->bindParam(":dinero",$datos["dinero"], PDO::PARAM_INT);
		if($stmt->execute()){
			return "ok";
		}else{
			print_r(Conexion::conectar()->errorInfo());
		}
		$stmt->close();
		$stmt=null;
	}

	#actualizar dia planilla
	static public function mdlActualizarDia($tabla, $datos){
		$stmt=Conexion::conectar()->prepare("UPDATE $tabla SET dia=:dia WHERE id_dia=:id_dia");
		$stmt->bindParam(":id_dia",$datos["id_dia"], PDO::PARAM_INT);
		$stmt->bindParam(":dia",$datos["dia"], PDO::PARAM_STR);
		if($stmt->execute()){
			return "ok";
		}else{
			print_r(Conexion::conectar()->errorInfo());
		}
		$stmt->close();
		$stmt=null;
	}

	#actualizar ubicacion
	static public function mdlRegistroUbi($tabla, $datos){
		$stmt=Conexion::conectar()->prepare("UPDATE $tabla SET latitud=:latitud, longitud=:longitud WHERE id_chofer=:id_chofer");
		$stmt->bindParam(":id_chofer",$datos["id_chofer"], PDO::PARAM_INT);
		$stmt->bindParam(":latitud",$datos["latitud"], PDO::PARAM_STR);
		$stmt->bindParam(":longitud",$datos["longitud"], PDO::PARAM_STR);
		if($stmt->execute()){
			return "ok";
		}else{
			print_r(Conexion::conectar()->errorInfo());
		}
		$stmt->close();
		$stmt=null;
	}

	

}