<?php 
class Conexion{
	static public function conectar(){
		$link =new PDO("mysql:host=localhost; dbname=u213578437_remis", "u213578437_remis", "Fabriprueba1$");
		$link->exec("set names utf8");
		return $link;
	}
}