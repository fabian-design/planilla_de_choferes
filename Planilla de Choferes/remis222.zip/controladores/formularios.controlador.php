<?php
class ControladorFormularios{

	#selecionar registros
	static public function ctrSelecionarRegistros($item, $valor){
		$tabla="perfil";
		$respuesta=ModeloFormularios::mdlSeleccionarRegistros($tabla, $item, $valor);
		return $respuesta;
	}
	#selecionar registros ACTIVO
	static public function ctrSelecionarRegistrosActivo($item, $valor){
		$tabla="perfil";
		$respuesta=ModeloFormularios::mdlSeleccionarRegistrosActivo($tabla, $item, $valor);
		return $respuesta;
	}
	#selecionar registros planilla
	static public function ctrSelecionarRegistrosplanilla($item, $valor, $item2, $valor2){
		$tabla="planilla";
		$respuesta=ModeloFormularios::mdlSeleccionarRegistrosplanilla($tabla, $item, $valor, $item2, $valor2);
		return $respuesta;
	}
	
	#selecionar registros planilla un solo registro devuelve
	static public function ctrSelecionarRegistrosplanillaFeach($item, $valor){
		$tabla="planilla";
		$respuesta=ModeloFormularios::mdlSeleccionarRegistros($tabla, $item, $valor);
		return $respuesta;
	}
	#selecionar registros sesion 
	static public function ctrSelecionarRegistrosSesion($item, $valor){
		$tabla="sesion";
		$respuesta=ModeloFormularios::mdlSeleccionarRegistros($tabla, $item, $valor);
		return $respuesta;
	}

	#inicio de sesion
	public function ctrIngreso(){
		if(isset($_POST["ingresoUsuario"])){
			$tabla="sesion";
			$item="user";
			$valor=$_POST["ingresoUsuario"];
			$respuesta=ModeloFormularios::mdlSeleccionarRegistros($tabla, $item, $valor);
			if($respuesta["user"]==$_POST["ingresoUsuario"] && $respuesta["password"]== $_POST["ingresocontrasena"]){
				if($respuesta["puesto"]=="admin"){
					$_SESSION["validarIngreso"]="ok";
					echo '<script>window.location ="index.php?pag=principal";</script>';
				}else if($respuesta["puesto"]=="control"){
					$_SESSION["validarIngreso"]="ok_control";
					echo '<script>window.location ="index.php?pag=control_principal";</script>';
				}else if($respuesta["puesto"]=="chofer"){
					$_SESSION["validarIngreso"]="ok_chofer";
					$_SESSION["id_chofer"]=$respuesta["id_chofer"];
					echo "<script>
					window.location ='index.php?pag=control_chofer';
					</script>;";
				}
				
			}else{
				echo '<div class="alert alert-danger">Error de ingreso</div>';
			}
		}
	}

	#registro planilla
	static public function ctrRegistro(){
		if(isset($_POST["importe"])){
			$tabla ="planilla";
			$datos=array("id_chofer"=>$_POST["idchofer"] ,"hora_salida"=>$_POST["horasalida"],  "salida"=>$_POST["salida"], "destino"=>$_POST["destino"], "hora_llegada"=>$_POST["horallegada"], "importe"=>$_POST["importe"]);
			$respuesta=ModeloFormularios::mdlRegistro($tabla, $datos);
			return $respuesta;
		}
	}

		#registro chofer
	static public function ctrRegistroChofer(){
		if(isset($_POST["nombre"])){
			$tabla ="perfil";
			$datos=array("nombre"=>$_POST["nombre"] ,"auto"=>$_POST["auto"],"porcentaje"=>$_POST["porcentaje"]);
			$respuesta=ModeloFormularios::mdlRegistroChofer($tabla, $datos);
			return $respuesta;
		}
	}
	#eliminar registro chofer
	public function ctrEliminarRegistro(){
		if(isset($_POST["eliminarRegistro"])){
			$tabla="perfil";
			$valor=$_POST["eliminarRegistro"];
			$respuesta=ModeloFormularios::mdlEliminarRegistro($tabla, $valor);
			if($respuesta == "ok"){
				echo '<script>
				if(window.history.replaceState){
					window.history.replaceState(null, null, window.location.href);
				}
				window.location ="index.php?pag=principal";
				</script>';
			}
		}
	}

	#eliminar planilla todos chofer
	public function ctrEliminarPlanilla_todos(){
		if(isset($_POST["eliminarRegistroTodos"])){
			$tabla="planilla";
			$valor=$_POST["eliminarRegistroTodos"];
			$respuesta=ModeloFormularios::mdlEliminarRegistro($tabla, $valor);
			if($respuesta == "ok"){
				echo '<script>
				if(window.history.replaceState){
					window.history.replaceState(null, null, window.location.href);
				}
				window.location ="index.php?pag=principal";
				</script>';
			}
		}
	}
	#actualizar registro chofer
	static public function ctrActualizarRegistro(){
		if(isset($_POST["actualizarnombre"])){
			$tabla ="perfil";
			$datos=array("llegada"=>$_POST["actualizarllegada"], "nombre"=>$_POST["actualizarnombre"] ,"id_chofer"=>$_POST["id_chofer"],"auto"=>$_POST["autoactualizar"], "porcentaje"=>$_POST["actualizarporcentaje"], "activo"=>$_POST["actualizaractivo"]);
			$respuesta=ModeloFormularios::mdlActualizarRegistro($tabla, $datos);
			return $respuesta;
		}
	}

	#registro cuenta
	static public function ctrRegistroCuenta(){
		if(isset($_POST["usuario"])){
			$tabla ="sesion";
			$datos=array("id_chofer"=>$_POST["id_chofer"], "user"=>$_POST["usuario"] ,"password"=>$_POST["password"],"puesto"=>$_POST["puesto"]);
			$respuesta=ModeloFormularios::mdlRegistroCuenta($tabla, $datos);
			return $respuesta;
		}
	}
	
	#eliminar sesion
	public function ctrEliminarSesion(){
		if(isset($_POST["eliminarSesion"])){
			$tabla="sesion";
			$valor=$_POST["eliminarSesion"];
			$respuesta=ModeloFormularios::mdlEliminarSesion($tabla, $valor);
			if($respuesta == "ok"){
				echo '<script>
				if(window.history.replaceState){
					window.history.replaceState(null, null, window.location.href);
				}
				window.location ="index.php?pag=principal";
				</script>';
			}
		}
	}


	#actualizar sesion
	static public function ctrActualizarSesion(){
		if(isset($_POST["aactualizarusuario"])){
			$tabla ="sesion";
			$datos=array("user"=>$_POST["aactualizarusuario"] ,"password"=>$_POST["actaulizarcontra"],"puesto"=>$_POST["actualizarpuesto"], "id"=>$_POST["id"]);
			$respuesta=ModeloFormularios::mdlActualizarSesion($tabla, $datos);
			return $respuesta;
		}
	}

	#eliminar planilla
	public function ctrEliminarPlanilla(){
		if(isset($_POST["eliminarPlanilla"])){
			$tabla="planilla";
			$valor=$_POST["eliminarPlanilla"];
			$respuesta=ModeloFormularios::mdlEliminarPlanilla($tabla, $valor);
			if($respuesta == "ok"){
				echo '<script>
				if(window.history.replaceState){
					window.history.replaceState(null, null, window.location.href);
				}
				window.location ="index.php?pag=principal";
				</script>';
			}
		}
	}

	#actualizar planilla
	static public function ctrActualizarPlanilla(){
		if(isset($_POST["actualizarid_planilla"])){
			$tabla ="planilla";
			$datos=array("id_planilla"=>$_POST["actualizarid_planilla"] ,"hora_salida"=>$_POST["actualizarhora_salida"],"salida"=>$_POST["actualizarsalida"], "destino"=>$_POST["actualizardestino"], "hora_llegada"=>$_POST["actualizarhora_llegada"], "importe"=>$_POST["actualizarimporte"]);
			$respuesta=ModeloFormularios::mdlActualizarPlanilla($tabla, $datos);
			return $respuesta;
		}
	}
	
	#actualizar planilla
	static public function ctrActualizarPlanillaDEVOLUCION(){
		if(isset($_POST["actualizarid_planilla"])){
			$tabla ="planilla";
			$datos=array("id_planilla"=>$_POST["actualizarid_planilla"] ,"devolucion"=>$_POST["devolucion"]);
			$respuesta=ModeloFormularios::mdlActualizarPlanillaDEVOLUCION($tabla, $datos);
			return $respuesta;
		}
	}


		#actualizar dinero a favor o encontra del chofer
	static public function ctrActualizarDinero(){
		if(isset($_POST["actualizar_dinero"])){
			$tabla ="perfil";
			$datos=array("dinero"=>$_POST["actualizar_dinero"], "id_chofer"=>$_POST["actualizar_id"]);
			$respuesta=ModeloFormularios::mdlActualizarDinero($tabla, $datos);
			return $respuesta;
		}
	}


		#actualizar fecha plantilla
	static public function ctrActualizarFecha(){
		if(isset($_POST["dia_planilla"])){
			$tabla ="dia_constante";
			$datos=array("dia"=>$_POST["dia_planilla"], "id_dia"=>1);
			$respuesta=ModeloFormularios::mdlActualizarDia($tabla, $datos);
			return $respuesta;
		}
	}

	#selecionar fecha planilla
	static public function ctrSelecionarFechaPlanilla($item, $valor){
		$tabla="dia_constante";
		$respuesta=ModeloFormularios::mdlSeleccionarRegistros($tabla, $item, $valor);
		return $respuesta;
	}
	#actualizar ubicacion
	static public function ctrRegistroUbi(){
		if(isset($_POST["id_ubi"])){
			$tabla ="perfil";
			$datos=array("id_chofer"=>$_POST["id_ubi"] ,"latitud"=>$_POST["latitud"],  "longitud"=>$_POST["longitud"]);
			$respuesta=ModeloFormularios::mdlRegistroUbi($tabla, $datos);
			return $respuesta;
		}
	}
	
}
