<?php 
class ControladorPlantilla{
	#metodo para llamar a la plantilla
	public function ctrTraerPlantilla(){
		include"vistas/plantilla.php";
	}
}