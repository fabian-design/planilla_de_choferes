<?php 
session_start();
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>remiceria</title>


	<script src="https://kit.fontawesome.com/271d45b9b0.js" crossorigin="anonymous"></script>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	<!--logo -->
	<link rel="shortcut icon" type="image/x-icon" href="style/img/logo.png">
	<link rel="stylesheet" type="text/css" href="style/style_inicioSesion.css">
	<link rel="stylesheet" type="text/css" href="style/style_chofer.css">
	<link rel="stylesheet" type="text/css" href="style/style_planilla_viajes.css">
	<link rel="stylesheet" type="text/css" href="style/style_general.css">

	<!-- mapaa-->
	 <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin=""/>
</head>
<body style="background-image: url(style/img/fondo.jpg);">


	<?php 
	ini_set("date.timezone", "America/Argentina/Buenos_Aires");
	if(isset($_GET["pag"])){
		if($_GET["pag"]=="maps" ||$_GET["pag"]=="eliminar_todas_planillas" ||$_GET["pag"]=="salir" ||$_GET["pag"]=="control_planilla_chofer" ||$_GET["pag"]=="control_chofer" ||$_GET["pag"]=="control_planilla" ||$_GET["pag"]=="control_principal" ||$_GET["pag"]=="editar_planilla" ||$_GET["pag"]=="editar_sesion" ||$_GET["pag"]=="editar_eliminar_cuenta" ||$_GET["pag"]=="añadir_cuenta" ||$_GET["pag"]=="editar_chofer" ||$_GET["pag"]=="editar_eliminar_chofer" ||$_GET["pag"]=="añadir_chofer" ||$_GET["pag"]=="añadir_viaje" ||$_GET["pag"]=="principal"  || $_GET["pag"]=="inicio"|| $_GET["pag"]=="error404"|| $_GET["pag"]=="planilla"|| $_GET["pag"]=="devolucion"){
			include "paginas/".$_GET["pag"].".php";
		}else{
			include "paginas/error404.php";
		}
	}else{
		include "paginas/inicio.php";
	}

	?>
</body>
</html>