<?php 
if(isset($_SESSION["validarIngreso"])){
	if($_SESSION["validarIngreso"]!="ok"){
		echo '<script>window.location ="index.php?pag=inicio";</script>';
		return;
	}
}else{
	echo '<script>window.location ="index.php?pag=inicio";</script>';
	return;
}
 ?>


<h1>Editar/Eliminar Chofere</h1>
<?php  
$usuarios=ControladorFormularios::ctrSelecionarRegistros(null, null);
?>
<table class="table table-dark table-hover">
	<thead>
		<tr>
			<th>Id</th>
			<th>Nombre</th>
			<th>Porcentaje</th>
			<th>Estado</th>
			<th>Accion</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($usuarios as $key => $value): ?>
			<tr>
				<td><?php echo$value["id_chofer"]; ?></td>
				<td><?php echo$value["nombre"]; ?></td>
				<td><?php echo$value["porcentaje"]; ?></td>
				<td><?php echo$value["activo"]; ?></td>
				<td>
					<div class="btn-group">
						<a href="index.php?pag=editar_chofer&id=<?php echo$value["id_chofer"]; ?>" class="btn btn-warning"><i class="fas fa-pencil-alt"></i></a>
						<form method="post">
							<input type="hidden" name="eliminarRegistro" value="<?php echo$value["id_chofer"]; ?>">
							<button type="submit" class="btn btn-danger"><i class="fas fa-trash-alt"></i></button>
							<?php 
							$eliminar= new ControladorFormularios();
							$eliminar->ctrEliminarRegistro();
							?>
						</form>

					</div>
				</td>
			</tr>
		<?php endforeach ?>
	</tbody>
</table>
