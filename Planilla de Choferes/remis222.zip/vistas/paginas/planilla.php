<?php 
if(isset($_SESSION["validarIngreso"])){
	if($_SESSION["validarIngreso"]!="ok"){
		echo '<script>window.location ="index.php?pag=inicio";</script>';
		return;
	}
}else{
	echo '<script>window.location ="index.php?pag=inicio";</script>';
	return;
}
 ?>
<?php 
if(isset($_GET["id"])){
	$item="id_chofer";
	$valor=$_GET["id"];
	$item2="fecha";
	$valor2=$_GET["fecha"];
	$acumulador=0;
	$usuarios=ControladorFormularios::ctrSelecionarRegistrosplanilla($item, $valor, $item2, $valor2);
	}
 ?>
 <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


<h2>Planilla</h2> 
<p style="text-align: center; color: #fff; font-size: 150%;">Fecha: <?php echo $valor2; ?></p>

<table class="table table-dark table-hover">
	<thead>
		<tr>
			<th>Id Chofer</th>
			<th>Hora salida</th>
			<th>Salida</th>
			<th>Destino</th>
			<th>Hora llegada</th>
			<th>Importe</th>
			<th>Devolucion</th>
			<th>Accion</th>
			
		</tr>
	</thead>
	<tbody>
		<?php foreach ($usuarios as $key => $value): ?>
			<tr>
				<?php $acumulador=$acumulador+$value["importe"] ?>
				<td><?php echo$value["id_chofer"]; ?></td>
				<td><?php echo$value["hora_salida"]; ?></td>
				<td><?php echo$value["salida"]; ?></td>
				<td><?php echo$value["destino"]; ?></td>
				<td><?php echo$value["hora_llegada"]; ?></td>
				<td><?php echo$value["importe"]; ?></td>
				<td><?php echo$value["devolucion"]; ?></td>
				<td>
					<div class="btn-group">
						<a href="index.php?pag=editar_planilla&id=<?php echo$value["id_planilla"]; ?>" class="btn btn-warning"><i class="fas fa-pencil-alt"></i></a>
						<form method="post">
							<input type="hidden" name="eliminarPlanilla" value="<?php echo$value["id_planilla"]; ?>">
							<button type="submit" class="btn btn-danger"><i class="fas fa-trash-alt"></i></button>
							<?php 
							$eliminar= new ControladorFormularios();
							$eliminar->ctrEliminarPlanilla();
							?>
						</form>

					</div>
				</td>
			</tr>
		<?php endforeach ?>
	</tbody>
</table>
<a type="button" href="index.php?pag=añadir_viaje&id=<?php echo$_GET["id"]; ?>" class="btn btn-dark" data-toggle="button" aria-pressed="false" autocomplete="off">
	Agregar viaje
</a>
 
<?php 
$acumuladorr= $acumulador;
if(isset($_GET["id"])){
	$item="id_chofer";
	$valor=$_GET["id"];
	$acumulador=0;
	$usuarioss=ControladorFormularios::ctrSelecionarRegistros($item, $valor);
	}
 ?>
 <br>

<h1 id="acumulador">Dinero recaudado por chofer:  $<?php echo $acumuladorr ?>.</h1>
<h1 id="porcentaje">Dinero a favor del chofer: $<?php echo $usuarioss["dinero"]; ?>.</h1>
<h1 id="porcentaje">Porcentaje de la Remiceria: <?php echo $usuarioss["porcentaje"]; ?>%.</h1>
<p id="parrafo" style="color: white; font-size: 200%; text-align: center;"></p>
<script type="text/javascript">
	var acumulador=parseInt('<?php echo $acumuladorr; ?>');
	var porcentaje=parseInt('<?php echo $usuarioss["porcentaje"]; ?>');
	var dinerochof=parseInt('<?php echo $usuarioss["dinero"]; ?>');
	var redondeo=redondeo-dinerochof;
	redondeo= acumulador/100;
	redondeo=redondeo*porcentaje;
	redondeo=Math.round(redondeo);
	document.getElementById("parrafo").innerHTML="Dinero a Recibir: $"+ redondeo;	
</script>
<br>
<form method="post">
<p style="color: #fff; text-align: center; font-size: 110%;">Dinero a favor de la empresa (se coloca signo “–“antes), dinero a favor del chofer (coloca monto normal). Si el monto es exacto se coloca un 0. </p>

<input style="margin-left: 45%;" type="number" placeholder="gastos" name="actualizar_dinero" value="<?php echo $usuarioss["dinero"]; ?>" id="pdchofer"><br>
<input type="hidden" placeholder="gastos" name="actualizar_id" value="<?php echo $usuarioss["id_chofer"]; ?>" id="pdchofer" >
<button type="submit" class="btn btn-dark" style="margin-left: 48%; margin-top: 1%;">guardar</button>
<?php
 $actualizar = ControladorFormularios::ctrActualizarDinero();
 if($actualizar == "ok"){
 	echo '<script>
 	if(window.history.replaceState){
 		window.history.replaceState(null, null, window.location.href);
 	}
 	</script>';
 	echo '<div class="alert alert-success">Usuario actualizado</div> <script>setTimeout(function(){window.location="index.php?pag=principal";},2000);</script>';
 }
 ?>
</form>