<?php 
if(isset($_SESSION["validarIngreso"])){
	if($_SESSION["validarIngreso"]!="ok"){
		echo '<script>window.location ="index.php?pag=inicio";</script>';
		return;
	}
}else{
	echo '<script>window.location ="index.php?pag=inicio";</script>';
	return;
}
 ?>



 <form  method="post" enctype="multipart/form-data">
 	<section class="form-register">
 		<h1>añadir cuenta</h1>
 		<div class="form-group">
 			<label for="text">usuario:</label>
 			<input type="text" class="controls" id="nombre" name="usuario">
 		</div>
 		<div class="form-group">
 			<label for="text">contraseña:</label>
 			<input type="password" class="controls" id="auto" name="password">
 		</div>
 		<div class="form-group">
 			<label for="text">puesto:</label>
 			<input type="text" class="controls" id="porcetaje" name="puesto" placeholder="admin/chofer/control">
 		</div>
 		<div class="form-group">
 			<label for="text">id del chofer:</label>
 			<input type="number" class="controls" id="id_chofer" name="id_chofer">
 		</div>

 		<?php 
 		$registro=ControladorFormularios::ctrRegistroCuenta();
 		if ($registro=="ok") {
 			echo '<script>
 			if(window.history.replaceState){
 				window.history.replaceState(null, null, window.location.href);
 			}
 			</script>';
 			echo '<div class="alert alert-success">Registro correcto</div><script>setTimeout(function(){window.location="index.php?pag=principal";},1000);</script>';
 		}
 		?>
 		<button type="submit" class="btn btn-primary">Crear cuenta</button>
 	</section>
 </form>

