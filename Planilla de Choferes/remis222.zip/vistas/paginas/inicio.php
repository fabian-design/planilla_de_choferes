
<form  method="post">
  <section class="form-register">
        <h4>Formulario Registro</h4>
        <input class="controls" type="text" name="ingresoUsuario" required id="Ingrese su Usuario" placeholder="Ingrese su Usuario">
        <input class="controls" type="password" name="ingresocontrasena" required id="Ingrese su Contraseña" placeholder="Ingrese su Contraseña">
        <button type="submit" class="botons">Ingresar</button>
    </section>
</form>
<?php 
	$ingreso= new ControladorFormularios();
	$ingreso->ctrIngreso();
?>

