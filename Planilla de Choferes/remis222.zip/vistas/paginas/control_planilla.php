<?php 
if(isset($_SESSION["validarIngreso"])){
	if($_SESSION["validarIngreso"]!="ok_control"){
		echo '<script>window.location ="index.php?pag=inicio";</script>';
		return;
	}
}else{
	echo '<script>window.location ="index.php?pag=inicio";</script>';
	return;
}
 ?>
 <?php 
if(isset($_GET["id"])){
	$item="id_chofer";
	$valor=$_GET["id"];
	$item2="fecha";
	$valor2=$_GET["fecha"];
	$acumulador=0;
	$usuarios=ControladorFormularios::ctrSelecionarRegistrosplanilla($item, $valor, $item2, $valor2);
	}
 ?>
 <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


<h2>Planilla</h2> 
<p style="text-align: center; color: #fff; font-size: 150%;">Fecha: <?php echo $valor2; ?></p>

<table class="table table-dark table-hover">
	<thead>
		<tr>
			<th>Id Chofer</th>
			<th>Hora salida</th>
			<th>Salida</th>
			<th>Destino</th>
			<th>Hora llegada</th>
			<th>Importe</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($usuarios as $key => $value): ?>
			<tr>
				<?php $acumulador=$acumulador+$value["importe"] ?>
				<td><?php echo$value["id_chofer"]; ?></td>
				<td><?php echo$value["hora_salida"]; ?></td>
				<td><?php echo$value["salida"]; ?></td>
				<td><?php echo$value["destino"]; ?></td>
				<td><?php echo$value["hora_llegada"]; ?></td>
				<td><?php echo$value["importe"]; ?></td>
			</tr>
		<?php endforeach ?>
	</tbody>
</table>

 
<?php 
$acumuladorr= $acumulador;
if(isset($_GET["id"])){
	$item="id_chofer";
	$valor=$_GET["id"];
	$acumulador=0;
	$usuarioss=ControladorFormularios::ctrSelecionarRegistros($item, $valor);
	}
 ?>
 <br>

<h1 id="acumulador">Dinero recaudado por chofer:  $<?php echo $acumuladorr ?>.</h1>
<h1 id="porcentaje">Dinero a favor del chofer: $<?php echo $usuarioss["dinero"]; ?>.</h1>
<h1 id="porcentaje">Porcentaje de la Remiceria: <?php echo $usuarioss["porcentaje"]; ?>%.</h1>
<p id="parrafo" style="color: white; font-size: 200%; text-align: center;"></p>
<script type="text/javascript">
	var acumulador=parseInt('<?php echo $acumuladorr; ?>');
	var porcentaje=parseInt('<?php echo $usuarioss["porcentaje"]; ?>');
	var dinerochof=parseInt('<?php echo $usuarioss["dinero"]; ?>');
	var redondeo=redondeo-dinerochof;
	redondeo= acumulador/100;
	redondeo=redondeo*porcentaje;
	redondeo=Math.round(redondeo);
	document.getElementById("parrafo").innerHTML="Dinero a Recibir: $"+ redondeo;	
</script>