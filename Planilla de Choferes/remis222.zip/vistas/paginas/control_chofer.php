<?php 
if(isset($_SESSION["validarIngreso"])){
	if($_SESSION["validarIngreso"]!="ok_chofer"){
		echo '<script>window.location ="index.php?pag=inicio";</script>';
		return;
	}
}else{
	echo '<script>window.location ="index.php?pag=inicio";</script>';
	return;
}
 ?>
 <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
 	<!-- Links -->
 	<ul class="navbar-nav">
 		<li class="nav-item">
 			<a class="nav-link" href="index.php?pag=salir">Cerrar Sesion</a>
 		</li>	
 	</ul>
 </nav>
<?php 
	$fecha_planilla=ControladorFormularios::ctrSelecionarFechaPlanilla("id_dia", 1);
 ?>   
<h1>Lista de Conductores</h1> 
<form method="post">
	<input type="text" name="dia_planilla" id="fecha" placeholder="aaaa-mm-dd"  style="background-color: #ffc107; margin-left: 1%; margin-bottom: 1%;" value="<?php echo $fecha_planilla["dia"]; ?>"> 
	<button type="submit">actualizar</button>
	<?php
	$actualizar = ControladorFormularios::ctrActualizarFecha();
	if($actualizar == "ok"){
		echo '<script>
		if(window.history.replaceState){
			window.history.replaceState(null, null, window.location.href);
		}
		</script>';
		echo '<div class="alert alert-success">Usuario actualizado</div> <script>setTimeout(function(){window.location="index.php?pag=control_chofer";},500);</script>';
	}
	?>
</form>
<?php 
$item="id_chofer";
$valor= $_SESSION["id_chofer"];
$usuarios=ControladorFormularios::ctrSelecionarRegistros($item, $valor);
?>

<table class="table table-dark table-hover">
	<thead>
		<tr>
			<th>Id</th>
			<th>Nombre</th>
			<th>Estado</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td><?php echo$usuarios["id_chofer"]; ?></td>
			<td><a href="index.php?pag=control_planilla_chofer&id=<?php echo$usuarios["id_chofer"]; ?>&fecha=<?php echo $fecha_planilla["dia"]; ?>" class="btn btn-warning"><?php echo$usuarios["nombre"]; ?></a></td>
			<td><?php echo$usuarios["activo"]; ?></td>
		</tr>
	</tbody>
</table>
