<?php 
if(isset($_SESSION["validarIngreso"])){
	if($_SESSION["validarIngreso"]!="ok"){
		echo '<script>window.location ="index.php?pag=inicio";</script>';
		return;
	}
}else{
	echo '<script>window.location ="index.php?pag=inicio";</script>';
	return;
}
 ?>


<nav class="navbar navbar-expand-sm bg-dark navbar-dark">

	<!-- Links -->
	<ul class="navbar-nav">

		<!-- Dropdown -->
		<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
				Administracion Choferes
			</a>
			<div class="dropdown-menu">
				<a class="dropdown-item" href="index.php?pag=añadir_chofer">Agregar chofer</a>
				<a class="dropdown-item" href="index.php?pag=editar_eliminar_chofer">Editar/Eliminar</a>
			</div>
		</li>
		<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
				Administracion Cuentas
			</a>
			<div class="dropdown-menu">
				<a class="dropdown-item" href="index.php?pag=añadir_cuenta">Agregar cuenta</a>
				<a class="dropdown-item" href="index.php?pag=editar_eliminar_cuenta">Editar/Eliminar</a>
			</div>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="index.php?pag=eliminar_todas_planillas">Eliminar planillas</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="index.php?pag=maps">Mapa</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="index.php?pag=salir">Cerrar Sesion</a>
		</li>	
	</ul>
</nav>
<?php 
	$fecha_planilla=ControladorFormularios::ctrSelecionarFechaPlanilla("id_dia", 1);
 ?>   
<h1>Listado de Choferes</h1> 
<form method="post">
	<input type="text" name="dia_planilla" id="fecha" placeholder="aaaa-mm-dd"  style="background-color: #ffc107; margin-left: 1%; margin-bottom: 1%;" value="<?php echo $fecha_planilla["dia"]; ?>"> 
	<button type="submit" class="btn btn-dark">actualizar</button>
	<?php
	$actualizar = ControladorFormularios::ctrActualizarFecha();
	if($actualizar == "ok"){
		echo '<script>
		if(window.history.replaceState){
			window.history.replaceState(null, null, window.location.href);
		}
		</script>';
		echo '<div class="alert alert-success">Usuario actualizado</div> <script>setTimeout(function(){window.location="index.php?pag=principal";},500);</script>';
	}
	?>
</form>
<?php  
$usuarios=ControladorFormularios::ctrSelecionarRegistrosActivo(null, null);
?>

<table class="table table-dark table-hover">
	<thead>
		<tr>
			<th>Id</th>
			<th>Nombre</th>
			<th>Estado</th>
			<th>Orden de llegada</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($usuarios as $key => $value): ?>
		<tr>
			<td><?php echo$value["id_chofer"]; ?></td>
			<td><a href="index.php?pag=planilla&id=<?php echo$value["id_chofer"]; ?>&fecha=<?php echo $fecha_planilla["dia"]; ?>" class="btn btn-warning"><?php echo$value["nombre"]; ?></a></td>
			<td><?php echo$value["activo"]; ?></td>
			<td><?php echo$value["llegada"]; ?></td>
		</tr>
		<?php endforeach ?>
	</tbody>
</table>
