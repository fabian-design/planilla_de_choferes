<?php 
if(isset($_SESSION["validarIngreso"])){
	if($_SESSION["validarIngreso"]!="ok"){
		echo '<script>window.location ="index.php?pag=inicio";</script>';
		return;
	}
}else{
	echo '<script>window.location ="index.php?pag=inicio";</script>';
	return;
}
 ?>


<h1>Editar/Eliminar Cuenta</h1>
<?php  
$usuarios=ControladorFormularios::ctrSelecionarRegistrosSesion(null, null);
?>
<table class="table table-dark table-hover">
	<thead>
		<tr>
			<th>Id</th>
			<th>Usuario</th>
			<th>Contraseña</th>
			<th>Puesto</th>
			<th>Accion</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($usuarios as $key => $value): ?>
			<tr>
				<td><?php echo$value["id"]; ?></td>
				<td><?php echo$value["user"]; ?></td>
				<td><?php echo$value["password"]; ?></td>
				<td><?php echo$value["puesto"]; ?></td>
				<td>
					<div class="btn-group">
						<a href="index.php?pag=editar_sesion&id=<?php echo$value["id"]; ?>" class="btn btn-warning"><i class="fas fa-pencil-alt"></i></a>
						<form method="post">
							<input type="hidden" name="eliminarSesion" value="<?php echo$value["id"]; ?>">
							<button type="submit" class="btn btn-danger"><i class="fas fa-trash-alt"></i></button>
							<?php 
							$eliminar= new ControladorFormularios();
							$eliminar->ctrEliminarSesion();
							?>
						</form>

					</div>
				</td>
			</tr>
		<?php endforeach ?>
	</tbody>
</table>
