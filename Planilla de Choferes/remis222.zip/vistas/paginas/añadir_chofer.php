<?php 
if(isset($_SESSION["validarIngreso"])){
	if($_SESSION["validarIngreso"]!="ok"){
		echo '<script>window.location ="index.php?pag=inicio";</script>';
		return;
	}
}else{
	echo '<script>window.location ="index.php?pag=inicio";</script>';
	return;
}
 ?>


 <form method="post" enctype="multipart/form-data">
 	<section class="form-register">
 		<h4>Añadir Chofer</h4>
 		<input type="text" class="controls" placeholder="Ingresa nombre" id="nombre" name="nombre">
 		<input type="text" class="controls" placeholder="Ingresa auto" id="nombre" name="auto" >
 		<input type="number" class="controls" placeholder="Ingresa porcentaje sin %" id="tamaño" name="porcentaje" > 
 		<?php 
 		$registro=ControladorFormularios::ctrRegistroChofer();
 		if ($registro=="ok") {
 			echo '<script>
 			if(window.history.replaceState){
 				window.history.replaceState(null, null, window.location.href);
 			}
 			</script>';
 			echo '<div class="alert alert-success">Registro correcto</div><script>setTimeout(function(){window.location="index.php?pag=principal";},1000);</script>';
 		}
 		?>
 		<button type="submit" class="btn btn-primary">Cargar chofer</button>
 	</section>
 </form>


