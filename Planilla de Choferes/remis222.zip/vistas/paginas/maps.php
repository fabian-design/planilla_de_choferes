<?php  
	$usuarios=ControladorFormularios::ctrSelecionarRegistrosActivo(null, null);
	echo '<script>setTimeout(function(){location.href=location.href;},35000);</script>';
	
	//echo "<h1>" .date("F j, Y, g:i a")."</h1>";  
?>
 <div id="myMap" style="height: 100vh;"></div>
 <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
 <script type="text/javascript">
 	let myMap = L.map('myMap').setView([<?php echo $usuarios[0]["latitud"]; ?>, <?php echo $usuarios[0]["longitud"]; ?>], 13)

 	L.tileLayer(`https://tile.openstreetmap.org/{z}/{x}/{y}.png`, {
 		maxZoom: 25,
 	}).addTo(myMap);
 	<?php foreach ($usuarios as $key => $value): ?>
 		var marker = L.marker([<?php echo$value["latitud"]; ?>, <?php echo$value["longitud"]; ?>]);
 		marker.bindPopup('<?php echo$value["nombre"]; ?>');
 		marker.addTo(myMap);
 	<?php endforeach ?>



 	</script>