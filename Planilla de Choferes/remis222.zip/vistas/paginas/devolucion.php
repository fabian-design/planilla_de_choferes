


<?php 
if(isset($_GET["id"])){
	$item="id_planilla";
	$valor=$_GET["id"];
	$usuario=ControladorFormularios::ctrSelecionarRegistrosplanillaFeach($item, $valor);
	}
 ?>

 <form  method="post">
 	<section class="form-register">
 		<h4>Editar planilla</h4>
 		<div class="form-group">
 			<label for="text">Id planilla:</label>
 			<input class="controls" type="number" name="actualizarid_planilla" id="idchofer" placeholder="Id planilla" value="<?php echo $usuario["id_planilla"]; ?>">
 		</div>

 		<div class="form-group">
 			<label for="text">Devolucion:</label>
 			<input class="controls" type="text" name="devolucion" id="horasalida" placeholder="Devolucion" >
 		</div>

 		</div>

 		<button type="submit" class="botons">Actualizar</button>
 		<?php 
 		$actualizar = ControladorFormularios::ctrActualizarPlanillaDEVOLUCION();
 		if($actualizar == "ok"){
 			echo '<script>
 			if(window.history.replaceState){
 				window.history.replaceState(null, null, window.location.href);
 			}
 			</script>';
 			echo '<div class="alert alert-success"> actualizado</div> <script>setTimeout(function(){window.location="index.php?pag=control_chofer";},500);</script>';
 		}
 		?>
 	</section>
 </form>

