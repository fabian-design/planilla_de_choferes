<?php 
if(isset($_SESSION["validarIngreso"])){
	if($_SESSION["validarIngreso"]!="ok"){
		echo '<script>window.location ="index.php?pag=inicio";</script>';
		return;
	}
}else{
	echo '<script>window.location ="index.php?pag=inicio";</script>';
	return;
}
 ?>


<?php 
if(isset($_GET["id"])){
	$item="id";
	$valor=$_GET["id"];
	$usuario=ControladorFormularios::ctrSelecionarRegistrosSesion($item, $valor);
	}
 ?>

 <form method="post">
 	<section class="form-register">
 		<h1 class="text-center py-3">Editar Sesion</h1>
 		<div class="form-group">
 			<label for="text">usuario:</label>
 			<input type="text" class="controls" id="nombre" name="aactualizarusuario" value="<?php echo $usuario["user"]; ?>">
 		</div>
 		<div class="form-group">
 			<label for="text">contraseña:</label>
 			<input type="text" class="controls" id="auto" name="actaulizarcontra" value="<?php echo $usuario["password"]; ?>">
 		</div>
 		<div class="form-group">
 			<label for="text">puesto:</label>
 			<input type="text" class="controls" id="porcetaje" name="actualizarpuesto" placeholder="admin/chofer/control" value="<?php echo $usuario["puesto"]; ?>">
 		</div>
 		<input type="hidden" name="id" value="<?php echo $usuario["id"]; ?>">
 		
 		<button type="submit" class="btn btn-primary">Actualizar</button>
 		<?php 
 		$actualizar = ControladorFormularios::ctrActualizarSesion();
 		if($actualizar == "ok"){
 			echo '<script>
 			if(window.history.replaceState){
 				window.history.replaceState(null, null, window.location.href);
 			}
 			</script>';
 			echo '<div class="alert alert-success">Usuario actualizado</div> <script>setTimeout(function(){window.location="index.php?pag=principal";},2000);</script>';
 		}
 		?>
 	</section>
 </form>
