<?php 
if(isset($_SESSION["validarIngreso"])){
	if($_SESSION["validarIngreso"]!="ok"){
		echo '<script>window.location ="index.php?pag=inicio";</script>';
		return;
	}
}else{
	echo '<script>window.location ="index.php?pag=inicio";</script>';
	return;
}
 ?>
<?php 
if(isset($_GET["id"])){
	$item="id_chofer";
	$valor=$_GET["id"];
	$usuarios=ControladorFormularios::ctrSelecionarRegistrosplanillaFeach($item, $valor);
	}
 ?>
 

 <form  method="post" enctype="multipart/form-data">
 	<section class="form-register">
 		<h4>Agregar Viaje</h4>
 		<div class="form-group">
 			<label for="text">Id chofer:</label>
 			<input class="controls" type="number" name="idchofer" id="idchofer" placeholder="Id chofer" value="<?php echo$usuarios["id_chofer"]; ?>">
 		</div>

 		<div class="form-group">
 			<label for="text">hora salida:</label>
 			<input class="controls" type="text" name="horasalida" id="horasalida" placeholder="hh:mm">
 		</div>

 		<div class="form-group">
 			<label for="text">salida:</label>
 			<input class="controls" type="text" name="salida" id="correo" placeholder="desde...">
 		</div>

 		<div class="form-group">
 			<label for="text">Destino:</label>
 			<input class="controls" type="text" name="destino" id="correo" placeholder="hasta...">
 		</div>

 		<div class="form-group">
 			<label for="text">Hora llegada:</label>
 			<input class="controls" type="text" name="horallegada" id="horallegada" placeholder="hh:mm">
 		</div>

 		<div class="form-group">
 			<label for="text">Importe:</label>
 			<input class="controls" type="number" name="importe" id="importe" placeholder="$">
 		</div>
 		<?php 
 		$registro=ControladorFormularios::ctrRegistro();
 		if ($registro=="ok") {
 			echo '<script>
 			if(window.history.replaceState){
 				window.history.replaceState(null, null, window.location.href);
 			}
 			</script>';
 			echo '<div class="alert alert-success">Registro correcto</div><script>setTimeout(function(){window.location="index.php?pag=principal";},1000);</script>';
 		}
 		?>
 		<button type="submit" class="botons">Cargar viaje</button>
 	</section>
 </form>



