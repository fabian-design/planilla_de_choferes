<?php 
if(isset($_SESSION["validarIngreso"])){
	if($_SESSION["validarIngreso"]!="ok"){
		echo '<script>window.location ="index.php?pag=inicio";</script>';
		return;
	}
}else{
	echo '<script>window.location ="index.php?pag=inicio";</script>';
	return;
}
 ?>


<?php 
if(isset($_GET["id"])){
	$item="id_chofer";
	$valor=$_GET["id"];
	$usuario=ControladorFormularios::ctrSelecionarRegistros($item, $valor);
	}
 ?>

 
 <form  method="post">
 	<section class="form-register">
 		<h4>Editar Registros chofer</h4>
 		<input type="text" class="controls" placeholder="Ingresa nombre" id="nombre" name="actualizarnombre" value="<?php echo $usuario["nombre"]; ?>">
 		<input type="text" class="controls" placeholder=" auto" id="nombre" name="autoactualizar" value="<?php echo $usuario["auto"]; ?>">
 		<input type="number" class="controls" placeholder="porcentaje " id="tamaño" name="actualizarporcentaje" value="<?php echo $usuario["porcentaje"]; ?>"> 
 		<label>Estado</label>
 		<input type="number" class="controls" placeholder="estado " id="tamaño" name="actualizaractivo" value="<?php echo $usuario["activo"]; ?>">
 		<label for="text">Orden de llegada</label>
 		<input type="number" class="controls" placeholder="llegada " id="tamaño" name="actualizarllegada" value="<?php echo $usuario["llegada"]; ?>">
 		<input type="hidden" name="id_chofer" value="<?php echo $usuario["id_chofer"]; ?>">
 		<button type="submit" class="botons">Actualizar</button>
 	</section>
 	<?php 
 	$actualizar = ControladorFormularios::ctrActualizarRegistro();
 	if($actualizar == "ok"){
 		echo '<script>
 		if(window.history.replaceState){
 			window.history.replaceState(null, null, window.location.href);
 		}
 		</script>';
 		echo '<div class="alert alert-success">Usuario actualizado</div> <script>setTimeout(function(){window.location="index.php?pag=principal";},2000);</script>';
 	}
 	?>
 </form>
