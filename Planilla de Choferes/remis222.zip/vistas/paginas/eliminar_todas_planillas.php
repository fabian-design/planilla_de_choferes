<h1>Eliminar todas las planillas de cada chofer</h1>
<?php  
$usuarios=ControladorFormularios::ctrSelecionarRegistros(null, null);
?>

<table class="table table-dark table-hover">
	<thead>
		<tr>
			<th>Id</th>
			<th>Nombre</th>
			<th>Eliminar</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($usuarios as $key => $value): ?>
		<tr>
			<td><?php echo$value["id_chofer"]; ?></td>
			<td><a href="index.php?pag=planilla_elimininar_choferes&id=<?php echo$value["id_chofer"]; ?>" class="btn btn-warning"><?php echo$value["nombre"]; ?></a></td>
			<td>
					<div class="btn-group">
						
						<form method="post">
							<input type="hidden" name="eliminarRegistroTodos" value="<?php echo$value["id_chofer"]; ?>">
							<button type="submit" class="btn btn-danger"><i class="fas fa-trash-alt"></i></button>
							<?php 
							$eliminar= new ControladorFormularios();
							$eliminar->ctrEliminarPlanilla_todos();
							?>
						</form>

					</div>
				</td>
		</tr>
		<?php endforeach ?>
	</tbody>
</table>
