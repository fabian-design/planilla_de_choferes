<?php 
if(isset($_SESSION["validarIngreso"])){
	if($_SESSION["validarIngreso"]!="ok"){
		echo '<script>window.location ="index.php?pag=inicio";</script>';
		return;
	}
}else{
	echo '<script>window.location ="index.php?pag=inicio";</script>';
	return;
}
 ?>


<?php 
if(isset($_GET["id"])){
	$item="id_planilla";
	$valor=$_GET["id"];
	$usuario=ControladorFormularios::ctrSelecionarRegistrosplanillaFeach($item, $valor);
	}
 ?>

 <form  method="post">
 	<section class="form-register">
 		<h4>Editar planilla</h4>
 		<div class="form-group">
 			<label for="text">Id planilla:</label>
 			<input class="controls" type="number" name="actualizarid_planilla" id="idchofer" placeholder="Id planilla" value="<?php echo $usuario["id_planilla"]; ?>">
 		</div>

 		<div class="form-group">
 			<label for="text">hora salida:</label>
 			<input class="controls" type="text" name="actualizarhora_salida" id="horasalida" placeholder="hh:mm" value="<?php echo $usuario["hora_salida"]; ?>">
 		</div>

 		<div class="form-group">
 			<label for="text">salida:</label>
 			<input class="controls" type="text" name="actualizarsalida" id="correo" placeholder="desde..." value="<?php echo $usuario["salida"]; ?>">
 		</div>

 		<div class="form-group">
 			<label for="text">Destino:</label>
 			<input class="controls" type="text" name="actualizardestino" id="correo" placeholder="hasta..." value="<?php echo $usuario["destino"]; ?>">
 		</div>

 		<div class="form-group">
 			<label for="text">Hora llegada:</label>
 			<input class="controls" type="text" name="actualizarhora_llegada" id="horallegada" placeholder="hh:mm" value="<?php echo $usuario["hora_llegada"]; ?>" >
 		</div>

 		<div class="form-group">
 			<label for="text">Importe:</label>
 			<input class="controls" type="number" name="actualizarimporte" id="importe" placeholder="$" value="<?php echo $usuario["importe"]; ?>" >
 		</div>

 		<button type="submit" class="botons">Actualizar</button>
 		<?php 
 		$actualizar = ControladorFormularios::ctrActualizarPlanilla();
 		if($actualizar == "ok"){
 			echo '<script>
 			if(window.history.replaceState){
 				window.history.replaceState(null, null, window.location.href);
 			}
 			</script>';
 			echo '<div class="alert alert-success">Usuario actualizado</div> <script>setTimeout(function(){window.location="index.php?pag=principal";},2000);</script>';
 		}
 		?>
 	</section>
 </form>

